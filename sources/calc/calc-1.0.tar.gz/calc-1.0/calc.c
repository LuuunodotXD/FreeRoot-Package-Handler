// calc.c
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Uso: calc <num> <op> <num>\n");
        fprintf(stderr, "Ops: + - * /\n");
        return 1;
    }

    double a = atof(argv[1]);
    double b = atof(argv[3]);
    char op = argv[2][0];
    double result;

    switch (op) {
        case '+': result = a + b; break;
        case '-': result = a - b; break;
        case '*': result = a * b; break;
        case '/':
            if (b == 0) { fprintf(stderr, "ERRO: divisão por zero\n"); return 1; }
            result = a / b;
            break;
        default:
            fprintf(stderr, "ERRO: operador inválido '%c'\n", op);
            return 1;
    }

    printf("%.6g\n", result);
    return 0;
}
